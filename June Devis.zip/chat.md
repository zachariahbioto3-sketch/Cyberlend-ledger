# WhatsApp Chat Export: June Devis
Export date: October 29, 2026 at 8:51 AM

---

## June 27, 2026

[10:56 PM] __Messages and calls are end-to-end encrypted. No one outside of this chat, not even WhatsApp, can read or listen to them. Tap to learn more.__

[10:56 PM] **You:** Yo

[11:14 PM] **June Devis:** Yoo

[11:15 PM] **You:** Ni Zach

[11:15 PM] **June Devis:** Wazi zach wacha nisave

---

## June 28, 2026

[8:20 AM] **June Devis:** 1. Client Role
People or companies looking for software solutions.
Features
Create company profile.
Post projects and jobs.
Search developers and teams.
Invite developers to bid.
Compare proposals.
Manage contracts.
Track milestones.
Approve deliverables.
Release payments.
Rate and review developers.
Purchase prototypes and software products.

[8:21 AM] **June Devis:** 2. Developer Role
Individuals or teams building software.
Features
Create professional profile.
Add skills and certifications.
Upload portfolio projects.
Apply for projects.
Submit quotations.
Communicate with clients.
Track tasks and milestones.
Deliver work.
Generate invoices.
Receive payments.
View ratings and performance metrics.

[8:43 AM] **June Devis:** Client → Posts Project → Developer Applies → Client Hires → Development → Payment → Review

[9:54 AM] **You:** [Document] phase one

[9:56 AM] **June Devis:** Nice

[2:21 PM] **June Devis:** Yooh kam na charger ya lapii

---

## June 29, 2026

[3:58 PM] **You:** https://reimagined-barnacle-qv7q7ww9966r34gww-8000.app.github.dev/v

[3:59 PM] **June Devis:** Site can't be reached

[3:59 PM] **June Devis:** Hii upande wetu tushaa unda website sasa tuko kwa app

[4:00 PM] **June Devis:** Alafu narequest unisaidie kudesign logo

[4:00 PM] **June Devis:** Najua venye inafaa kua already ni kutengeneza tu

[4:14 PM] **June Devis:** [Image]

[4:14 PM] **June Devis:** Anza na kudesign shield  kama hiyo ya Ferrari

[4:15 PM] **June Devis:** Ndani ikue white

[4:15 PM] **June Devis:** Then eliminate color red na green hapo juu

[4:16 PM] **June Devis:** Then replace SF na JV

[4:17 PM] **June Devis:** Ukimada unishow nikuchapie next step

[8:30 PM] **June Devis:** Yooh hii charger inacharge kweli

[8:31 PM] **You:** yap

[8:31 PM] **June Devis:** But pole pole sana

---

## June 30, 2026

[8:14 AM] **June Devis:** Nimetengenena logo na Name

[5:12 PM] **You:** [Document] Devis-main (2).zip

[5:13 PM] **June Devis:** Yeah keep pushing

[5:35 PM] **You:** tuma hiyo logo

[5:37 PM] **You:** [Image]

[5:37 PM] **June Devis:** Bro you're a genius

[5:38 PM] **You:** [Image]

[5:38 PM] **June Devis:** _This message was deleted_

[5:39 PM] **June Devis:** [Image]

[5:40 PM] **June Devis:** Nitume zingine ama?

[5:41 PM] **You:** yap the white one

[5:42 PM] **June Devis:** [Image]

[5:42 PM] **June Devis:** Hiyo ama?

[5:43 PM] **You:** [Image]

[5:45 PM] **June Devis:** Include the name nenogram technologies in the code

[5:47 PM] **You:** So i will redesign so that to meet these preferences .

[5:47 PM] **June Devis:**
> _You: So i will redesign so that to these preferences ._
Yeah

[5:47 PM] **June Devis:** But concept n the same

[5:48 PM] **June Devis:**
> _June Devis: Image_
Zoom in zimeshaa andikwa kitu utafanya ni  kuasighn each logo to the designated areas

[5:49 PM] **June Devis:** As indicated

[5:49 PM] **June Devis:** Zoom uone

[5:49 PM] **You:**
> _June Devis: But concept n the same_
ni the same only the brand and the style

[5:50 PM] **June Devis:**
> _You: ni the same only the brand and the style_
Yeah each style iko na place inafaa kuwekwa

[6:14 PM] **You:** we need someone who know how write a blog

[6:25 PM] **June Devis:**
> _You: we need someone who know how write a blog_
No problem wacha nitafute ama kuna msee unajua

[6:26 PM] **June Devis:** Nikipata nitakupea WhatsApp number yake umpee specifications

[6:29 PM] **June Devis:** Kuna dem anaweza

[6:38 PM] **You:**
> _June Devis: Kuna dem anaweza_
ok

[6:38 PM] **June Devis:**
> _You: ok_
Specifications

[7:53 PM] **June Devis:** Bro kesho utakua around uniletee laptop mwenye anaunda loan app anataka ainstall  software fln

[7:53 PM] **June Devis:** Napeleka before 1:00

[7:53 PM] **June Devis:** Kesho

[7:54 PM] **You:** kesho saa ngapi

[7:54 PM] **June Devis:** Probably 12:00

[7:55 PM] **You:** fiti

---

## July 1, 2026

[10:01 AM] **You:** https://devis-4xiu.onrender.com/register/

---

## July 2, 2026

[11:41 AM] **You:** https://devis-4xiu.onrender.com/register/

---

## July 3, 2026

[12:05 PM] **June Devis:** Yooh

[1:16 PM] **You:** Ozaa

[1:17 PM] **You:** Password ni gani

---

## July 4, 2026

[2:13 PM] **June Devis:**
> _You: Password ni gani_
Xan

[7:35 PM] **You:** ya comp

[7:35 PM] **June Devis:**
> _You: ya comp_
Xan

[7:37 PM] **You:** 👍

[7:38 PM] **June Devis:** Lowercase

[7:39 PM] **You:** setting

[7:39 PM] **June Devis:** Imefunguka?

[7:39 PM] **You:** yes

[7:39 PM] **June Devis:** Okay

[7:39 PM] **You:** but setting haifunguki

[7:40 PM] **June Devis:** Azin

[7:41 PM] **You:** inaleta note"the app cant open"

[7:41 PM] **June Devis:** Sasa sijui ngori iko wapi

[10:19 PM] **You:** https://www.youtube.com/live/10TevuMvhvk?si=Wu3EGgrr4nS-S001

---

## July 5, 2026

[7:27 PM] **June Devis:** How is it coming up so far

[8:00 PM] **You:** dealing with some errors

[8:01 PM] **June Devis:** What about implementation of  nenogram today and nenoshop

[8:01 PM] **June Devis:** Did you figure out a way to make it work

[8:02 PM] **You:** yap wacha nitakushow

[8:03 PM] **June Devis:** Good

---

## July 6, 2026

[8:02 PM] **You:** So net ime come Wacha ni shugulike

[9:41 PM] **June Devis:** Implement hizo features to the best of your ability

---

## July 8, 2026

[9:29 AM] **You:** bro am late

[9:29 AM] **You:** jana usikii tullikuwa na assessment

[9:48 AM] **You:** [Document] Devis-main (4).zip

[9:48 AM] **You:** system  inaendelea kuwa robust , from 116kb to 5mb msee

[9:48 AM] **You:** na bado

[10:13 AM] **June Devis:** Ngori

[10:23 AM] **June Devis:** Building the system is the hard part the rest is a walk in the park

[10:27 AM] **June Devis:**
> _You: Document: Devis-main (4).zip_
Enyewe ni robust

[10:30 AM] **You:** features added  eno — what we build today (MVP):
Django apps:

posts — articles, drafts, publishing workflow
categories — categories + tags
media — image uploads via Cloudinary
accounts — writer/editor/publisher roles

Editor: TipTap (via CDN — no npm needed) stored as JSON blocks in the database
Models (today):

Post — title, slug, content (JSON), featured image, meta description, status (draft/review/scheduled/published), scheduled_at, reading_time, views, author
Category — name, slug
Tag — name, slug
Revision — content snapshots for version history
MediaFile — uploaded images/files

Pages (today):

/neno/ — writer dashboard (all posts, stats)
/neno/new/ — editor page (TipTap)
/neno/<slug>/edit/ — edit existing post
/neno/<slug>/preview/ — preview before publish
/blog/ — public post listing
/blog/<slug>/ — public post detail

Features (today):

TipTap editor with toolbar (bold, italic, headings, lists, blockquotes, links, images, code, divider)
Slash commands (/heading, /image, /quote)
Auto-save every 30 seconds via AJAX
Word count + reading time (live)
SEO sidebar (slug, meta description, featured image)
Publishing workflow (Draft → Published)
Categories + tags
Breaking news flag
Schedule publish

[10:30 AM] **You:** hizi niza kuedit na post any news ama articales

[10:31 AM] **June Devis:** Smart move

[10:34 AM] **June Devis:** Nenogram today could be an ads tool thus attracting more money from people who want their tech companies or products advertised

[10:34 AM] **You:** Yap

[10:34 AM] **June Devis:** Good job

[10:36 AM] **You:** Ulemsee anaeza kutumia zip file ya cyberlend

[10:37 AM] **June Devis:** Nilimshow atume

[10:37 AM] **June Devis:** I spoke with him jana

[10:39 AM] **You:**
> _June Devis: I spoke with him jana_
Fiti

[11:16 AM] **You:** am projeting size of the project to reach 10 mb

[11:19 AM] **June Devis:**
> _You: am projeting size of the project to reach 10 mb_
Yeah with all the features it's possible

---

## July 9, 2026

[9:05 AM] **You:** Yo remind me on the other part coz nishamalizia ile part ya news nanogram today.

[9:06 AM] **You:**
> _You: Yo remind me on the other part coz nishamalizia ile part ya news nanogram today._
Hi part ilkuwa hell msee

[9:07 AM] **June Devis:**
> _You: Yo remind me on the other part coz nishamalizia ile part ya news nanogram today._
How many features have you implemented so far

[9:07 AM] **June Devis:**
> _You: Hi part ilkuwa hell msee_
Agreed

[9:07 AM] **You:** Editing tools na publishing function

[9:08 AM] **You:** Mostly Kwa news na mambo ya kupost

[9:08 AM] **June Devis:** Nenostore

[9:08 AM] **You:** Ok now remind the logic

[9:09 AM] **June Devis:** The store is where anybody can buy or sell software

[9:09 AM] **June Devis:** They just list

[9:10 AM] **You:** 👍

[9:11 AM] **June Devis:** Search and discover software.
AI-powered software recommendations.
Categories (Finance, AI, Security, Healthcare, Education, Business, etc.).
Free and paid software.
Reviews and ratings.
Screenshots, videos, and live demos.
Trial versions before purchase.
Automatic updates.
Secure payments.
Download history and license management.
Wishlist and favorites.

[9:12 AM] **June Devis:** This will guide you but feel free to implement additional features or adjustments

[9:13 AM] **You:** Now that is the part I was missing,"searching and discovering".

[9:14 AM] **June Devis:** For developers
Developer dashboard.
Upload and publish software.
Version management.
Sales and revenue analytics.
User feedback and bug reports.
API and SDK documentation.
Licensing options (subscription, one-time purchase, freemium).
Promotional tools and featured listings.
Team accounts for software companies.

[9:16 AM] **June Devis:** Security
Malware scanning before publication.
Developer identity verification.
Two-factor authentication.
Secure payment processing.
Digital license protection.
Copyright and intellectual property protection.

[10:24 AM] **June Devis:** Use the word "merchant" to reffer to people selling their software license etc

[10:28 AM] **June Devis:** The logic is simple there is a merchant and clients

[11:59 AM] **You:** Models, merchant dashboard, product upload, public store listing, product detail, M-Pesa purchase, license generation

[11:59 AM] **You:** hiyo ni phase one

[1:37 PM] **You:** na bado

[1:37 PM] **You:** [Document] phew msee in to a breake first almost ten mb

[2:05 PM] **June Devis:**
> _You: Document: phew msee i need to a breake first almost ten mb_
N mbayaaa n kumoto

[2:05 PM] **June Devis:**
> _You: hiyo ni phase one_
Good work

[2:06 PM] **You:** wacha nik come

---

## July 11, 2026

[11:09 AM] **You:** So yoo Nisha setup Kwa lapi saa operation naeza fanyia Kwa lapi but in kula vibaya nikifanyia Kwa lapi

[11:46 AM] **June Devis:** So tufanye aje

[11:46 AM] **June Devis:** Suggestions

[11:58 AM] **You:** Wacha tunichape nayo hivyo

[12:00 PM] **June Devis:** So laptop iko poa

[12:00 PM] **June Devis:** Intahandle project

[12:00 PM] **You:** Yap ikopoa

[12:00 PM] **June Devis:** Ok

[12:00 PM] **June Devis:** Stay vigilant na do your absolute best

[12:03 PM] **You:** [Image]

[12:06 PM] **June Devis:** What are you handling today

[12:06 PM] **June Devis:** Which part of nenogram

[12:07 PM] **You:** database restructuring

[12:08 PM] **June Devis:** Okay

[12:14 PM] **You:** the beauty of doing locally is that am some how not limited

[12:17 PM] **June Devis:**
> _You: the beauty of doing locally is that am some how not limited_
So it's kind of an advantage

[12:24 PM] **You:** yeah

[12:27 PM] **June Devis:** Na hiyo idea yako ya kuimplement a coding environment iko fity sana

[7:43 PM] **You:** Tuma hizo feature za socializations

[8:16 PM] **June Devis:** _This message was deleted_

[8:17 PM] **June Devis:** _This message was deleted_

[8:21 PM] **June Devis:** _This message was deleted_

[8:37 PM] **June Devis:** Zach forget this let me give a robust blue print

[8:37 PM] **June Devis:** Let me design

[8:41 PM] **June Devis:** Nenogram Social Hub – Product Blueprint (Version 1.0)
Purpose
The Nenogram Social Hub is the central community of the Nenogram ecosystem where developers, designers, cybersecurity professionals, founders, students, researchers, employers, investors, and technology enthusiasts connect, collaborate, share knowledge, and build their professional reputation.
Core Navigation
1. Home
The personalized feed containing:
Posts
Photos
Videos
Articles
Project updates
Startup updates
Polls
Trending discussions
2. Explore
Discover:
Trending people
Trending startups
Trending projects
Communities
Events
Recommended users
3. Search
Search for:
People
Companies
Startups
Projects
Communities
Jobs
Software
Posts
4. Communities
Users can:
Create communities
Join communities
Moderate communities
Share posts
Hold discussions
Examples:
Artificial Intelligence
Cybersecurity
Software Development
Web Development
Mobile Development
Cloud Computing
Robotics
Data Science
5. Projects
A space to:
Showcase projects
Share development progress
Find collaborators
Receive community feedback
6. Startups
Each startup includes:
Company profile
Product showcase
Hiring status
Funding status
Startup updates
7. Events
Host and discover:
Hackathons
Workshops
Conferences
Meetups
Live webinars
8. Messages
Communication tools:
Direct messages
Group chats
File sharing
Voice messages
Video calls
9. Notifications
Receive alerts for:
Likes
Comments
Mentions
New followers
Community activity
Collaboration requests
Job invitations
10. Profile
Each profile contains:
Profile photo
Cover photo
Bio
Skills
Portfolio
Experience
Education
Achievements
Contact links
Followers and Following
11. Settings
Manage:
Privacy
Security
Notification preferences
Appearance
Language
Connected accounts
Account verification
Content Types
Users can publish:
Text posts
Images
Videos
Articles
Polls
Code snippets
Project updates
Startup announcements
Event announcements
Engagement Features
Users can:
Like
Comment
Repost
Bookmark
Share
Follow
Mention users
Use hashtags
Unique Nenogram Features
Innovation Score
A platform-wide score based on meaningful contributions, including projects, knowledge sharing, and community participation.
Tech Passport
A verified professional record showing:
Projects
Skills
Certifications
Hackathons
Awards
Work history
Build Together
A collaboration feature where users can recruit teammates, join projects, or offer their expertise.
Problem Marketplace
Organizations and individuals publish real-world technical problems for the community to solve, with recognition or rewards for successful solutions.
Bottom Navigation
Home
Explore
Create
Messages
Profile
Design Principles
Clean and modern interface
Fast and responsive performance
Mobile-first design
Professional yet social experience
Strong privacy and security
Seamless integration with all Nenogram services
Vision
The Nenogram Social Hub is designed to become the professional networking and collaboration center of the Nenogram ecosystem, empowering people to build careers, launch startups, collaborate on projects, and advance technology through one unified platform.

[8:43 PM] **June Devis:** Is it too robust

[8:44 PM] **June Devis:** It borrows features from platform like what's up
YouTube and TikTok

[8:45 PM] __[Call]__

---

## July 14, 2026

[10:13 AM] **You:** am having a network problem

[10:17 AM] **You:** delaying production

[10:18 AM] **June Devis:** Mneti iko chini sana

[10:18 AM] **June Devis:** Na venye we are behind schedule

[10:19 AM] **You:** let see it will go

[8:17 PM] **June Devis:** Module Name
Hackathons
Navigation
Home
│
├── Hackathons
      ├── Discover
      ├── My Hackathons
      ├── Create Hackathon
      ├── Teams
      ├── Projects
      ├── Leaderboard
      ├── Mentors
      ├── Sponsors
      ├── Winners
      └── Archive
User Roles
Participant
Register
Join teams
Submit projects
Chat
View rankings
Receive awards
Team Leader
Create team
Invite members
Submit project
Manage team
Judge
Review submissions
Score projects
Leave feedback
Rank teams
Mentor
Guide teams
Answer questions
Schedule mentoring sessions
Organizer
Create hackathons
Approve participants
Manage judges
Manage sponsors
Publish winners
Sponsor
Sponsor challenges
View analytics
Offer prizes
Recruit participants
Admin
Full platform control
Hackathon Model
Each hackathon contains:
Basic Information
Title
Description
Banner image
Theme
Category
Difficulty
Organizer
Sponsors
Prize pool
Registration deadline
Start date
End date
Location
Online/Offline
Maximum participants
Team size
Categories
AI
FinTech
Cybersecurity
Web Development
Mobile Development
Cloud Computing
Robotics
Blockchain
Data Science
IoT
Gaming
Open Innovation
Registration Flow
User clicks
Register
↓
Accept Rules
↓
Create Team OR Join Existing Team
↓
Submit Team Details
↓
Registration Complete
Team System
Each team has
Team name
Logo
Description
Leader
Members
Skills
Invite link
Chat room
Submission Module
Each submission contains
Project title
Description
Problem statement
Solution
Features
Technologies used
GitHub repository
Live demo
Video presentation
Documentation
Presentation slides
Judging Dashboard
Judges score
Criteria
Weight
Innovation
25%
Technical Quality
25%
Design
15%
Business Potential
15%
Impact
10%
Presentation
10%
Automatic total score
Ranking updates automatically
Leaderboard
Display
Team Rank
Team Name
Score
Country
Category
Prize Position
Filters
Global
Country
University
Category
Mentorship
Mentors can
Accept appointments
Chat with teams
Review ideas
Schedule meetings
Give recommendations
Sponsor Portal
Sponsors can
Create sponsored challenges
Upload branding
Offer prizes
Recruit developers
View participant analytics
Notifications
Participants receive
Registration approved
Team invitation
Submission reminder
Judge feedback
Winner announcement
Prize notification
Awards Module
Supports
Cash prizes
Certificates
Digital trophies
Badges
Startup funding offers
Internship offers
Job offers
Project Gallery
After the event, projects remain visible with
Screenshots
Demo videos
GitHub link
Downloads
Likes
Comments
Technology stack
Team members
Analytics Dashboard
For organizers:
Total registrations
Active teams
Submission rate
Judge progress
Sponsor statistics
Audience engagement
Country distribution
Popular technologies
Database Tables
Core entities include:
Users
Hackathons
Categories
Teams
Team Members
Registrations
Projects
Project Files
Judges
Scores
Mentors
Sponsors
Awards
Notifications
Chats
Certificates

[8:17 PM] **June Devis:** Let the module name be something creative like neno play

[8:19 PM] **June Devis:** Fees might be implemented later

[8:19 PM] **June Devis:** Feel free and express yourself in your code

[8:20 PM] **June Devis:** Let me work on awards criteria

---

## July 15, 2026

[10:34 AM] **You:** [Forwarded] [Image]

[10:37 AM] **June Devis:** Yeah it's coming up just fine

[10:38 AM] **June Devis:** I have a new logo and all app designs

[10:38 AM] **June Devis:** The new logo is refined to be more tech oriented

[10:41 AM] **June Devis:** [Image]

[10:41 AM] **June Devis:** What do you think?

[10:42 AM] **You:** [Forwarded] [Image]

[10:42 AM] **You:** Phone screen size these is how it appears.

[10:43 AM] **You:**
> _June Devis: Image_
Fine ,but all should be black and white

[10:43 AM] **June Devis:**
> _You: Fine ,but all should be black and white_
What about the icons are they fine for branding

[10:44 AM] **June Devis:** Ama we proceed with our previous logo

[10:45 AM] **June Devis:** What is your take on that?

[10:45 AM] **You:**
> _June Devis: What about the icons are they fine for branding_
Super fine

[10:46 AM] **June Devis:** Ooh another thing there is a big difference between nenosphere and nenostream

[10:47 AM] **June Devis:** Work on them separately even though they borrow from each other

[10:48 AM] **You:** What is the difference

[10:48 AM] **You:** 🤔

[10:50 AM] **June Devis:** Neno stream will mostly be used to stream events like hackathons or used by tech companies to stream content like rocket launches etc it will also be used for tech videos like tiktok but now the feed will be pure tech

[10:51 AM] **June Devis:** On the other hand nenosphere will mostly be used like WhatsApp or x or telegram

[10:52 AM] **June Devis:** Mostly messaging

[10:53 AM] **June Devis:** Look at the logos I sent I've defined the concept

[10:54 AM] **You:** [Forwarded] [Video]

[10:55 AM] **June Devis:**
> _You: Video_
Kazi safi

[11:00 AM] **June Devis:** The socialisation hub for nenogram is composed of Nenosphere and neno stream

[11:00 AM] **June Devis:** The socialisation hub should exist in two parts

[11:12 AM] **June Devis:** Do you get the concept from the logos

---

## July 16, 2026

[10:42 PM] **June Devis:** Yo

---

## July 17, 2026

[11:11 AM] **You:** [Forwarded] Google Docs System Design: A Complete Guide
You are typing a sentence in a shared document. Halfway across the world, your colleague deletes the paragraph you are working in. Somehow, when you both look at the screen a moment later, the document makes sense. Your words appear, their deletion is reflected, and neither of you lost work. This seamless experience hides one of the most sophisticated engineering challenges in modern software: real-time collaborative editing at global scale.

Google Docs handles millions of concurrent users editing documents simultaneously, yet the interface feels as simple as a local text file. Behind that simplicity lies a distributed system managing operational transformations, multi-region replication across infrastructure like Bigtable and Spanner, and conflict resolution algorithms that run in milliseconds. Understanding how this works goes beyond academic curiosity. It is one of the most revealing System Design interview questions because it forces you to reason about consistency, latency, fault tolerance, and user experience all at once.

This guide breaks down the complete architecture of a Google Docs-like system. You will learn how to structure your answer in interviews, understand the trade-offs between operational transformation and CRDTs, and grasp why offline-first design is harder than it sounds. By the end, you will have a mental model for designing any real-time collaborative system, not just document editors.

The following diagram illustrates the high-level architecture connecting clients, collaboration servers, and the storage layer that powers real-time document editing.


High-level architecture of a Google Docs-like collaborative editing system
What makes Google Docs unique
Before diving into architecture, it helps to understand why Google Docs is fundamentally different from a simple text editor. A local word processor saves files to disk and handles one user at a time. Google Docs must handle multiple users typing in the same sentence at the same moment, synchronize their changes across unreliable networks, and ensure everyone sees the same final result. This requirement for real-time, multi-user collaboration shapes every architectural decision.

The system must deliver updates with latency under 200 milliseconds to feel responsive. It must scale horizontally to support millions of concurrent users across documents. Cross-platform support means the same synchronization logic works in browsers, mobile apps, and desktop clients.

Offline editing adds another layer. Users expect to keep working on airplanes or in areas with spotty connectivity, with their changes merging cleanly once they reconnect. These features create a unique combination of challenges around consistency, availability, and partition tolerance that makes Google Docs an ideal case study for distributed systems thinking.

Real-world context: Google Docs reportedly uses operational transformation as its core synchronization algorithm, a technique originally developed for collaborative systems in the 1980s. The same principles now power tools like Figma, Notion, and countless collaborative coding environments.

Understanding these unique constraints helps you frame your interview answer properly. When you lead with the specific challenges of real-time collaboration, you demonstrate that you are thinking about the actual problem being solved rather than reciting architecture patterns.

Core requirements of Google Docs System Design
Every strong System Design answer begins with requirements gathering. Jumping straight into architecture without clarifying what the system must do is a common interview mistake. Requirements give your answer structure and show interviewers you approach problems methodically rather than diving into solutions prematurely.

Functional requirements
The functional requirements define what users can do with the system. Real-time editing is the foundation. When one user types, every other collaborator must see that change appear almost instantly.

Version history must capture every change with timestamps and author information so users can roll back to earlier states or review who modified what. Document sharing requires a permissions model where users can be owners, editors, commenters, or viewers, with access controlled at both the document and link level. Offline editing allows users to continue working without internet connectivity, with changes queued locally and synchronized when the connection returns.

Non-functional requirements
Non-functional requirements define how well the system performs its functions. Low latency is critical because edits must propagate to all clients within 100 to 200 milliseconds for the collaboration to feel natural. High availability means the system should target 99.9% uptime or better since users expect Google Docs to simply work whenever they need it.

Fault tolerance ensures the system continues operating even when individual servers crash or network partitions occur. Data durability guarantees that documents are never lost, even during outages, through replication across multiple storage nodes and geographic regions.

Key trade-offs
Real-world systems cannot optimize everything simultaneously, and articulating trade-offs demonstrates engineering maturity. The tension between consistency and latency is central. You can apply edits instantly and resolve conflicts afterward, or delay updates to guarantee ordering, but not both.

Simplicity versus accuracy appears in offline synchronization, where supporting disconnected editing introduces complex edge cases around conflict resolution. Cost versus scalability surfaces in version history, where storing every keystroke provides precise rollback capability but increases storage and processing overhead significantly.

By clarifying requirements upfront, you set the foundation for a well-structured design. It signals to interviewers that you think about what systems need to deliver before deciding how to build them. With requirements established, we can now examine the major architectural components.

High-level architecture overview
The high-level architecture of a Google Docs-like system divides into several major components, each handling distinct responsibilities. This modular approach allows teams to scale, optimize, and debug each layer independently. Understanding these components and their interactions is essential for both interviews and real-world System Design.

The client application is what users interact with directly, whether in a browser or mobile app. It captures user input, renders document changes in real-time, and maintains a local representation of the document state. The client also handles optimistic updates, showing users their own changes immediately while waiting for server confirmation.

Collaboration servers act as traffic controllers for real-time editing. They receive operations from clients, apply transformation algorithms to resolve conflicts, and broadcast the resulting changes to all connected users viewing the same document. These servers maintain the authoritative document state and coordinate ordering across clients.

The storage layer persists documents, metadata, and version history durably. In Google’s infrastructure, this likely involves Bigtable for storing document content and operation logs, Spanner for strongly consistent metadata like permissions and sharing settings, and Colossus for large file attachments and blobs.

The synchronization service manages the real-time communication channels between clients and servers. WebSocket connections maintain persistent bidirectional channels so updates can push to clients instantly rather than requiring polling. Load balancers distribute incoming traffic across collaboration servers to prevent any single server from becoming a bottleneck during peak usage.

Historical note: Google’s storage infrastructure evolved from the original Google File System and Bigtable papers published in the mid-2000s. Spanner, which provides globally distributed strong consistency, was developed later to solve exactly the kinds of coordination problems that collaborative editing requires.

This modular design enables independent scaling. The collaboration servers handling real-time synchronization can scale separately from the storage layer optimized for durability. It also isolates failures. A problem in the versioning system does not bring down real-time editing. In interviews, walking through each component and explaining its role demonstrates you can think about systems at the right level of abstraction before diving into implementation details.

Real-time collaboration as the heart of the system
Real-time collaboration is what distinguishes Google Docs from traditional document editors. Multiple people typing, deleting, and formatting text simultaneously, with all changes appearing instantly for everyone, creates profound technical challenges. The core problem is deceptively simple to state. If two users edit the same position in a document at the same moment, how does the system decide what the final result should be?

Consider a concrete scenario. User A types the letter “X” at position 10 in a document. At the same instant, User B deletes the character at position 10. Without coordination, different clients might apply these operations in different orders, leading to divergent document states. User A might see “X” appear then disappear, while User B sees position 10 become empty with “X” never appearing. The system must ensure all clients converge to identical final states despite network delays causing operations to arrive in different orders.

The following diagram shows how two concurrent operations transform to produce a consistent result across clients.


Operational transformation resolving concurrent edits from two users
Operational transformation
Operational transformation, commonly called OT, is the algorithm Google Docs has historically used to solve this problem. The core idea is that every operation carries metadata about the document state it was created against. When operations arrive at the server, they are transformed relative to any operations that have been applied since the original state. This transformation adjusts positions and effects so the operation applies correctly to the current document state.

In the example above, OT would transform User A’s insert operation. Since User B’s delete removed a character at position 10, User A’s insert at position 10 might need to shift to position 9. Alternatively, the system might determine the insert should still happen at position 10 in the new document context.

The transformation rules ensure deterministic outcomes. Every client applying the same set of operations in any order will arrive at the same final document. OT has proven effective at scale but comes with complexity. The transformation functions must handle every possible combination of operations (insert-insert, insert-delete, delete-delete, formatting changes, and more), and proving correctness across all combinations is notoriously difficult.

Conflict-free replicated data types
CRDTs offer an alternative approach that has gained popularity in newer collaborative systems. Instead of transforming operations after the fact, CRDTs structure the underlying data so that concurrent modifications merge automatically without conflicts. Each character in a CRDT-based document might carry a unique identifier and position metadata that allows insertions to interleave correctly regardless of when they arrive. The mathematical properties of CRDTs guarantee eventual consistency without requiring a central coordination point.

CRDTs are conceptually simpler than OT because the merge logic is embedded in the data structure itself rather than requiring complex transformation functions. However, they can introduce storage overhead since each character needs additional metadata, and certain operations like moving text ranges can be harder to express efficiently. Modern systems like Figma use hybrid approaches, combining CRDT-like data structures with operational semantics for specific actions.

Pro tip: In interviews, demonstrating knowledge of both OT and CRDTs shows depth. Explain that OT is proven at Google-scale but complex to implement correctly, while CRDTs offer cleaner semantics but may require more storage. Discussing when you would choose one over the other demonstrates real engineering judgment.

Low latency is non-negotiable for real-time collaboration to feel natural. Studies show users perceive delays above 100 to 200 milliseconds as lag, breaking the illusion of simultaneous editing. This constraint drives architectural decisions from protocol choice (WebSockets over HTTP polling) to geographic server distribution. With the synchronization algorithm understood, we can examine how concurrent operations are handled in practice.

Handling concurrent editing
Concurrency is where theory meets reality. Multiple users might type in the same paragraph, sentence, or even character position. Without careful handling, edits overwrite each other, work gets lost, and documents become inconsistent across clients. The strategies for managing concurrent edits build on the transformation algorithms but involve additional coordination mechanisms.

Optimistic concurrency control is the dominant pattern. Rather than locking documents or sections when a user starts editing, the system allows everyone to edit simultaneously and reconciles changes afterward. Locks would introduce unacceptable latency and create poor user experiences when someone forgets to release a lock. Optimistic control keeps the interface responsive while the transformation layer handles conflicts transparently.

Each operation carries a version vector or sequence number indicating the document state it was based on. When operations arrive at the server, the version information determines how to transform them relative to other concurrent operations.

Conflict resolution rules ensure deterministic outcomes when transformation alone is insufficient. If two users type different characters at exactly the same position and time, the system needs a tiebreaker. Common approaches include using client identifiers (lower ID wins) or timestamps (earlier timestamp wins). The specific rule matters less than consistency. All clients must apply the same rule so they converge to identical states. Some systems preserve both changes by inserting them in a deterministic order rather than discarding either.

The combination of optimistic control, version vectors, and deterministic conflict resolution creates a system where users experience fluid, lock-free editing while the backend maintains consistency. Explaining this in interviews shows you understand both the user experience requirements and the distributed systems mechanisms that enable them. Next, we will explore how documents are stored and versioned to support this real-time collaboration.

Document storage and versioning
Real-time synchronization gets edits to all clients quickly, but those edits must also be stored durably. The storage layer in a Google Docs-like system does far more than save text files. It maintains complete version history, enables fast document loading, and ensures data survives hardware failures and regional outages. The design choices here directly impact performance, cost, and reliability.

Storage architecture
Rather than rewriting entire documents on every keystroke, the system stores an append-only log of operations. Each edit becomes a record in this log with metadata including the operation type, position, content, timestamp, and author. Append-only writes are fast and naturally preserve history. To reconstruct a document, the system replays operations from the beginning of the log. This approach works well for synchronization since new clients can receive just the operations they have missed.

However, replaying thousands of operations every time someone opens a document would be prohibitively slow. Periodic snapshots solve this problem. The system periodically saves complete document states as checkpoints. When a client loads a document, it fetches the most recent snapshot and then applies only the operations that occurred after that snapshot.

This hybrid of snapshots and operation logs balances write efficiency with read performance. Tuning the snapshot frequency involves trade-offs. More frequent snapshots speed up document loading but increase storage costs and write amplification.

Google’s infrastructure likely distributes this storage across specialized systems. Bigtable provides high-throughput storage for document content and operation logs, with its column-family model suited to append-heavy workloads. Spanner offers globally consistent storage for metadata like document ownership, sharing settings, and access permissions where strong consistency matters more than raw throughput. Colossus, Google’s distributed file system, handles large binary attachments like embedded images.

The following diagram shows how snapshots and operation logs work together to enable efficient document loading.


Snapshot and operation log architecture for efficient document storage
Version history implementation
Every change is recorded with a timestamp and author, enabling users to browse version history and restore earlier states. This audit trail also helps the system debug synchronization issues by replaying exactly what happened. The granularity of version history involves trade-offs. Capturing every keystroke provides precise rollback but requires substantial storage. Some systems batch small edits into larger version checkpoints that are more storage-efficient while still useful for recovery.

Log compaction and pruning manage storage growth over time. Once a snapshot is created, the operations before it are needed only for historical browsing, not for normal document loading. Systems can archive older operation logs to cheaper storage tiers or compress them more aggressively. The key insight is that recent history needs fast access while older history can tolerate higher latency.

Watch out: A common interview mistake is proposing to store complete document copies for every version. This approach works for small documents but becomes prohibitively expensive at scale. Always mention delta-based storage with periodic snapshots as the more practical approach.

The storage layer must also handle multi-region replication for both availability and latency. Users in Tokyo should load documents quickly from nearby servers, while the system ensures their edits propagate globally. This replication introduces consistency questions that we will explore further in later sections. With storage architecture established, we can examine how updates flow through the system in real time.

Real-time synchronization and messaging
Synchronization is the connective tissue that makes collaboration feel instantaneous. When you type a character, it must appear on your collaborators’ screens within milliseconds. This requires a communication architecture optimized for speed, reliability, and scale. The choices here determine whether the system feels seamless or laggy.

WebSockets provide the foundation for real-time communication. Unlike HTTP request-response patterns where clients must poll for updates, WebSockets establish persistent bidirectional connections. Once connected, either the client or server can push data instantly without the overhead of connection establishment. This low-latency channel is essential for collaborative editing where every keystroke needs immediate propagation.

The collaboration servers implement a publish-subscribe model for document updates. When a client connects to edit a document, it subscribes to that document’s update channel. Every operation the server receives is validated, transformed if necessary, and then published to all subscribers. This fan-out pattern ensures all connected clients receive updates with minimal delay. Message queues like Kafka or Google’s Pub/Sub can help buffer and distribute these updates reliably, especially when some clients experience temporary connectivity issues.

Edge servers and geographic distribution reduce latency for global users. A user in Singapore should not have to wait for round trips to servers in the United States. By deploying WebSocket servers and caching layers across multiple regions, the system can route users to nearby infrastructure. Updates are then replicated between regions in the background. This architecture accepts that users in different regions might see slightly different document states for brief moments (tens of milliseconds) in exchange for dramatically improved perceived performance.

Consistency considerations
The system aims for immediate consistency where all views match as quickly as network physics allows. In practice, eventual consistency is the realistic guarantee. During network partitions or high load, clients may temporarily diverge but will converge once conditions normalize. The OT or CRDT algorithms ensure that convergence happens correctly regardless of the order operations arrive.

The challenge compounds when considering failure scenarios. What happens when a WebSocket connection drops mid-operation? The client must buffer unsent operations and retry on reconnection. What if the retry succeeds but the original operation also went through? Operations must be idempotent or carry unique identifiers so duplicates can be detected and ignored. These edge cases are where robust real-time systems distinguish themselves from fragile prototypes.

Real-world context: Slack, Discord, and other real-time applications face similar synchronization challenges. The patterns used in Google Docs, including WebSockets, pub-sub, and geographic distribution, appear across the industry wherever low-latency updates are required.

Balancing speed and correctness is what makes synchronization design fascinating. Users expect instant feedback, but the system cannot sacrifice consistency for speed. The engineering art lies in making the complex machinery invisible so collaboration feels effortless. Beyond synchronization, collaborative documents require careful attention to who can do what, which brings us to security and permissions.

Security and permissions
When multiple people edit shared documents, access control becomes critical infrastructure rather than an afterthought. The system must ensure that viewers cannot edit, that private documents stay private, and that permission checks happen fast enough not to bottleneck collaboration. At Google’s scale, this means handling millions of documents with complex sharing relationships efficiently.

Access control model
Google Docs implements role-based permissions with four primary levels. Viewers can read document content but cannot modify it. Commenters can add comments and suggestions but cannot change the actual text. Editors can modify content freely. Owners have full control including the ability to change sharing settings and delete the document. Each document maintains an access control list (ACL) mapping user identities to their roles.

Documents can be shared through direct user invitations or through shareable links. Link-based sharing adds complexity because the permission level is encoded in the link itself rather than being tied to a specific user identity. The system must validate every view or edit request against the ACL, checking both user-specific grants and link-based permissions. This validation must happen on every operation without adding perceptible latency.

Authorization at scale
Google developed Zanzibar, a global authorization system, to handle permission checks across their products at massive scale. Zanzibar uses a relationship-based model where permissions are expressed as relationships between users and resources. Rather than storing flat ACLs, it represents permission graphs that can express complex inheritance and group membership. Checking if a user can edit a document becomes a graph traversal problem that Zanzibar optimizes through caching and precomputation.

Fine-grained permissions add another dimension of complexity. Some collaborative systems allow per-section or per-paragraph access control, where different users can edit different parts of the same document. This granularity is useful for sensitive documents but dramatically increases the complexity of permission checking and conflict resolution. Most implementations, including Google Docs, keep permissions at the document level to maintain manageable complexity.

All communication uses TLS encryption in transit, and documents are encrypted at rest on storage servers. Access logs track who viewed or edited each document, enabling security audits and unauthorized access detection. Privacy compliance requirements like GDPR add constraints around data retention, deletion, and portability that influence storage architecture decisions.

Pro tip: In interviews, mentioning Zanzibar or relationship-based access control shows you understand how authorization scales beyond simple ACL lookups. Even if you do not know Zanzibar’s details, discussing how you would cache permission checks and handle group membership demonstrates systems thinking.

Security considerations must balance with usability. Making sharing too difficult defeats the purpose of collaborative editing. The system must make granting access easy while preventing accidental exposure of sensitive documents. With access control established, we need to consider what happens when parts of the system fail.

Fault tolerance and reliability
Users trust Google Docs with important work because they expect it to be available whenever needed and to never lose data. Meeting this expectation requires engineering for failure at every level. Servers crash, disks fail, networks partition, and data centers occasionally go offline. A reliable system survives all of these scenarios with minimal user impact.

Common failure scenarios include collaboration server crashes while users are actively editing, network partitions that isolate users or servers from each other, storage node failures that could cause data loss, and software bugs that corrupt document state. Each scenario requires specific mitigation strategies while the overall architecture must assume that anything can fail at any time.

Reliability mechanisms
Replication is the foundation of durability. Documents are stored in multiple locations, typically across different servers, racks, and geographic regions. If one copy becomes unavailable, others can serve requests. The replication factor (how many copies exist) trades storage cost against durability guarantees. Critical data like document content might be replicated more aggressively than less important metadata.

Collaboration servers often use a leader-follower architecture where one server coordinates updates for a particular document while followers stand ready to take over. When the leader fails, one of the followers is promoted through a leader election process. This failover should happen quickly enough that users experience at most a brief pause rather than losing their connection entirely. Automatic failover systems monitor server health and reroute traffic without human intervention.

Idempotency ensures that operations can be safely retried. If a network glitch causes a client to resend an operation, the server must recognize it as a duplicate and not apply it twice. This is typically implemented through unique operation identifiers that the server tracks. Idempotent operations make the system resilient to the retry storms that occur during partial failures.

The following table summarizes key reliability mechanisms and their purposes:

Mechanism	Purpose	Trade-off
Multi-region replication	Survive regional outages	Increased storage cost and replication latency
Leader-follower servers	Fast failover on server crash	Coordination complexity and potential split-brain
Idempotent operations	Safe retries during network issues	Additional server-side state tracking
Periodic snapshots	Faster recovery and reduced log replay	Write amplification and storage overhead
Reliability is ultimately about trust. Users will not adopt a collaborative tool if they fear losing work to a server crash. Google Docs has built this trust through years of engineering investment in fault tolerance. In interviews, discussing specific failure scenarios and your mitigation strategies demonstrates that you think about systems realistically rather than assuming ideal conditions. Beyond server failures, we must consider a different kind of disconnection. Users working offline.

Offline editing and synchronization challenges
Offline editing transforms Google Docs from a web application into something more powerful. Users can continue working on airplanes, in subway tunnels, or anywhere with unreliable connectivity. When they reconnect, their changes merge seamlessly with updates from other collaborators. This capability dramatically improves usability but introduces the hardest synchronization challenges in the entire system.

How offline editing works
When a device loses connectivity, the client application does not stop functioning. Instead, it switches to a local-first mode where edits are captured in the browser’s IndexedDB, localStorage, or a mobile app’s local database. Each operation is queued with full metadata including timestamps, version information, and operation details. The user interface continues updating locally, providing immediate feedback even though changes are not reaching the server.

Upon reconnection, the client sends its queued operations to the server for reconciliation. The server must merge these offline edits with any changes that occurred while the user was disconnected. This is where operational transformation or CRDTs earn their keep. The transformation algorithms must handle potentially large divergences between the local and server states, applying all offline operations in a way that produces consistent results across clients.

Conflict resolution complexity
Offline conflicts are more severe than real-time conflicts because more divergence can accumulate. Consider a scenario where one user deletes an entire paragraph while offline, while another user (also offline or online) heavily edits that same paragraph. When both reconnect, the system must decide how to resolve this. Should the deletion win, discarding the other user’s edits? Should both changes be preserved somehow? There is no universally correct answer, and different systems make different choices based on their use cases.

Most systems apply a last-writer-wins or deterministic merge strategy that may not perfectly reflect user intent but at least produces consistent results. Some systems notify users of conflicts and let them manually resolve, though this adds friction to the experience. The goal is ensuring users never lose work silently while keeping the normal case frictionless.

Order of operations matters even with conflict resolution algorithms. Offline edits must be applied in the correct causal order relative to online edits. Version vectors track these dependencies, ensuring that an edit based on document state A is transformed correctly even if many other edits occurred between A and the current state.

Watch out: Many candidates oversimplify offline mode in interviews, treating it as “just queue operations and send them later.” The complexity lies in conflict resolution when offline changes interact with concurrent online changes. Always address how you would handle cases where offline and online users edited the same content.

Supporting offline editing significantly increases system complexity but provides substantial usability benefits. It also demonstrates a mature understanding of distributed systems. Every client is essentially a node in a distributed system that can partition from the others at any time. With offline editing understood, we can examine how the system scales to support millions of concurrent users.

Scalability in Google Docs System Design
Google Docs serves millions of users worldwide, with thousands of documents being edited concurrently at any moment. Designing for this scale requires careful architecture across every layer. A system that works perfectly for ten users can completely fall apart at ten thousand without the right scaling strategies.

Scaling collaboration servers
Horizontal scaling distributes load across many servers rather than relying on increasingly powerful individual machines. Adding more collaboration servers linearly increases the system’s capacity to handle concurrent editing sessions. This approach requires that servers be stateless or that state be externalized to shared storage, allowing any server to handle requests for any document.

Document-based sharding assigns each document to a specific collaboration server or server group. This localization means that all operations for a given document flow through the same server, simplifying transformation ordering and reducing coordination overhead. Consistent hashing algorithms can map document identifiers to servers while handling server additions and removals gracefully.

Load balancers distribute incoming WebSocket connections across available servers. They monitor server health and route around failures. For WebSocket connections, load balancers must maintain session affinity so that a client’s connection stays with the same backend server, or the architecture must support seamless handoff between servers.

Global distribution and data partitioning
Geo-distribution places servers and data replicas in multiple regions worldwide. A user in Europe connects to European servers and reads from European data replicas, experiencing low latency regardless of where the document was created. This distribution requires replication mechanisms to keep data synchronized across regions, introducing the latency versus consistency trade-offs discussed earlier.

Large datasets are broken into partitions (sometimes called shards) that can be stored and processed independently. Partitioning strategies must balance even data distribution against access patterns. Hot documents being edited by many users need more resources than dormant documents, so the system may dynamically reallocate based on load.

The following diagram illustrates how global users connect to regional servers with data replicating between regions.


Global distribution architecture with regional clusters and cross-region replication
Handling peak load
Caching layers reduce load on backend storage and improve response times. Frequently accessed documents are cached in memory, serving reads without hitting the persistent storage layer. Cache invalidation must be handled carefully to ensure users see fresh data, especially when documents are being actively edited.

Autoscaling adjusts capacity based on demand. During work hours when editing activity peaks, the system automatically provisions additional servers. During off-peak hours, it scales down to reduce costs. Effective autoscaling requires monitoring systems that detect load changes quickly and provisioning systems that can bring new servers online within seconds.

Scalability is often the differentiator between good designs and great ones in interviews. Explaining how your architecture handles growth from thousands to millions of users demonstrates that you think about systems at the scale that top companies operate. With the architecture fully explored, we can turn to practical interview preparation.

Common interview questions and how to approach them
Google Docs appears frequently in System Design interviews because it combines real-time collaboration, scalability, and fault tolerance into a single problem. Practicing these questions prepares you for variations involving any collaborative system. The key is having a framework that you can adapt to different interviewers and time constraints.

Typical questions include designing a system like Google Docs from scratch, ensuring consistency when multiple users edit simultaneously, choosing storage strategies for real-time versioning, handling conflicts when two users type in the same location, and achieving global latency under 200 milliseconds. Each question might emphasize different aspects, but the underlying architecture remains similar.

Approach framework
Start by clarifying requirements before drawing anything. Ask about scale (how many concurrent users, documents, edits per second), features (offline support, version history depth, permission complexity), and constraints (latency targets, consistency requirements). This conversation demonstrates that you think about the problem space before jumping to solutions.

Lay out the high-level architecture early, identifying major components and their interactions. Explain clients, collaboration servers, storage, and synchronization as distinct layers. This gives you and the interviewer a shared vocabulary for the rest of the discussion and shows you can think at the appropriate level of abstraction.

Dive into the hard parts that distinguish Google Docs from simpler systems. Concurrent editing with OT or CRDTs, offline synchronization, and global scale are the areas where you can demonstrate depth. Do not spend equal time on every component. Focus on what makes this problem interesting.

Explain trade-offs explicitly throughout your answer. OT versus CRDTs, strong versus eventual consistency, snapshot frequency, storage efficiency versus retrieval speed. Interviewers value candidates who recognize that engineering involves choices rather than optimal solutions.

Do not forget failure handling and security. Mentioning replication, failover, idempotency, and permission checking shows you think about production systems rather than idealized designs. These concerns distinguish senior engineers from those who only consider happy paths.

Pro tip: Practice explaining your design out loud with a timer. Most System Design interviews are 45 to 60 minutes, and you need to cover requirements, architecture, deep dives, and trade-offs within that window. Recording yourself helps identify where you spend too much time or skip important points.

The goal is demonstrating systematic thinking and clear communication rather than producing a perfect design. Interviewers evaluate your reasoning process as much as your conclusions. With interview approach covered, let us examine common mistakes to avoid.

Mistakes to avoid when designing Google Docs
Even strong candidates make predictable mistakes in Google Docs System Design interviews. Recognizing these pitfalls helps you avoid them and present a more polished answer. Most mistakes stem from either skipping important considerations or overcomplicating solutions.

Skipping requirements gathering is perhaps the most common error. Jumping directly into architecture without clarifying what the system needs to do makes your solution feel ungrounded. Even if the interviewer has a standard problem in mind, asking clarifying questions shows methodical thinking and gives you information to guide your design choices.

Ignoring concurrency misses the core challenge. Real-time collaboration is what distinguishes Google Docs from a simple cloud file storage. If you spend most of your time on storage architecture without explaining how concurrent edits are handled, you have missed the point. Always address operational transformation, CRDTs, or your chosen conflict resolution approach.

Overlooking offline capabilities is another gap. Many candidates treat Google Docs as purely online, ignoring that offline editing is a key feature. Mentioning local storage, operation queuing, and reconnection synchronization demonstrates awareness of the full user experience.

Neglecting fault tolerance leaves your design incomplete. Production systems must handle server crashes, network partitions, and data corruption. Explaining replication strategies, failover mechanisms, and idempotent operations shows you think about real-world operational concerns.

Overcomplicating the solution is the opposite problem. Adding unnecessary components, obscure algorithms, or theoretical constructs without clear justification makes your design harder to follow and raises questions about your judgment. Start with the simplest design that meets requirements, then add complexity only where justified.

Poor communication undermines even good technical thinking. Silently sketching diagrams without explaining your reasoning leaves interviewers guessing. Narrate your thought process, explain why you are making each choice, and check in with the interviewer periodically to ensure you are addressing their interests.

Interviewers value clarity and trade-off analysis more than theoretical elegance. A simple, well-explained design that acknowledges limitations is stronger than a complex design you cannot clearly articulate. With mistakes identified, here is a structured preparation strategy.

Preparation strategy for Google Docs System Design interviews
Preparing for Google Docs System Design interviews requires practice rather than memorization. You need to internalize the architecture well enough to adapt it to different problem framings and interviewer questions. The following roadmap builds this capability systematically.

Step 1: master distributed systems fundamentals
Before tackling Google Docs specifically, ensure you understand the building blocks. Study load balancing strategies and when to use different approaches. Learn sharding and partitioning patterns for distributing data across servers. Understand caching layers and cache invalidation challenges. Review consistency models including strong, eventual, and causal consistency, knowing when each is appropriate.

Step 2: study real-time collaboration specifically
Deep dive into the algorithms that make collaborative editing possible. Understand operational transformation well enough to explain how two concurrent operations are transformed. Read about CRDTs and their mathematical properties. Study how WebSocket connections differ from HTTP and why they matter for real-time systems. The more deeply you understand these concepts, the more confidently you can discuss trade-offs.

Step 3: practice related design problems
Work through design prompts for collaborative text editors, shared whiteboards, real-time messaging apps, and multiplayer games. Each problem exercises similar muscles in concurrency control, state synchronization, and conflict resolution. The variety helps you recognize patterns and adapt your knowledge to novel situations.

Step 4: build mock interview habits
Time yourself for 45 to 60 minutes per problem to simulate interview conditions. Use a whiteboard, drawing tablet, or online diagramming tool to practice visual communication. Most importantly, practice explaining trade-offs out loud. Your ability to articulate why you made each choice matters as much as the choices themselves.

Step 5: learn from structured resources
Courses like Grokking the System Design Interview provide frameworks and walkthroughs for problems exactly like Google Docs. These resources help you see how experts structure answers and what level of detail interviewers expect. They are particularly valuable if you are new to System Design interviews or returning after a long break.

Step 6: refine your communication
Record yourself explaining solutions and review the recordings critically. Notice where you ramble, skip important points, or fail to explain your reasoning. Focus on being clear, concise, and structured. In interviews, how you explain matters as much as what you explain. Consistent practice builds the confidence to stay calm and organized under interview pressure.

Conclusion
Google Docs represents one of the most complete case studies for understanding modern distributed systems. Building a real-time collaborative editor requires solving problems across the entire stack. Synchronization algorithms resolve concurrent edits. Storage systems balance versioning with performance. Messaging infrastructure delivers updates in milliseconds. Permission systems scale to millions of documents. Fault tolerance mechanisms keep the system reliable despite inevitable failures. Each component involves trade-offs that have no universally correct answers, only choices appropriate to specific requirements and constraints.

The patterns you learn from Google Docs extend far beyond document editing. The same synchronization challenges appear in collaborative design tools like Figma, multiplayer games, real-time dashboards, and any system where multiple users interact with shared state. Understanding operational transformation and CRDTs gives you vocabulary to discuss these problems precisely. Grasping the interplay between consistency and latency helps you reason about distributed systems generally. These skills transfer directly to building and scaling production systems.

Real-time collaboration at global scale will only become more important as remote work continues expanding and users expect seamless multiplayer experiences in every application. The architectural patterns are evolving too. Local-first software, edge computing, and new CRDT implementations are pushing the boundaries of what collaborative systems can do. Engineers who understand these foundations will be well-positioned to build the next generation of tools.

Approach your Google Docs System Design interview with structure, clarity, and confidence. Lead with requirements, explain your architecture at the right level of abstraction, dive deep on synchronization and conflict resolution, and articulate trade-offs explicitly. With practice, the complexity becomes manageable and the conversation becomes an opportunity to demonstrate genuine engineering depth.

[11:13 AM] **You:** These is the architect I need to implement in article and news editing tools

[11:14 AM] **June Devis:** The system should be world class

---

## July 18, 2026

[3:55 PM] **You:** [Forwarded] Lines Words Characters Property
----- ----- ---------- --------
18501

[3:55 PM] **You:** Lines of code for the entire project

[3:58 PM] **June Devis:** Wueh crazy

[8:22 PM] **June Devis:** Umeanza Hackathons

[8:31 PM] **You:** Ndio naendelea nayo

[8:31 PM] **June Devis:** Wagwan

[9:55 PM] **You:** wacha nichange the design to some how silky and liquid glass so that we can conitunue.

[9:56 PM] **June Devis:** Ok

[9:58 PM] **You:** [Image] now these is my reference

[9:59 PM] **June Devis:** We must ensure Nenogram is a masterpiece

---

## July 19, 2026

[1:23 PM] **You:** checkout these i  just found it online https://stitch.withgoogle.com/preview/5455626419253236723?node-id=16cd49a9d8cd4adcb3b60bb85c062f7e

[1:28 PM] **You:** so the tool that made is the same tool i will use to desinge our nenogram

[1:29 PM] **You:** screenshot i see how it look

[1:31 PM] **June Devis:** [album message]

[1:31 PM] **June Devis:** [Image]

[1:31 PM] **June Devis:** [Image]

[1:32 PM] **You:** not bad , if the tool can do that then it can do better

[1:32 PM] **June Devis:** [album message]

[1:32 PM] **June Devis:** [Image]

[1:32 PM] **June Devis:** [Image]

[1:32 PM] **June Devis:** [Image]

[1:32 PM] **June Devis:**
> _You: not bad , if the tool can do that then it can do better_
Yeah

[1:32 PM] **June Devis:** I talked to the developer

[1:33 PM] **June Devis:** He said he will be delivering the software anytime from now

[1:33 PM] **You:** ok lets wait

[1:33 PM] **You:**
> _June Devis: He said he will be delivering the software anytime from now_
anatuma files ama

[1:34 PM] **June Devis:** Application

[1:34 PM] **June Devis:** Full software

[1:34 PM] **June Devis:** Kazi itabaki ni polishing na improvement kidogo

[1:35 PM] **You:** ok

[7:41 PM] **June Devis:** [Image]

---

## July 21, 2026

[12:38 PM] **You:** check put the math Let's do the math properly.

---

*Current pricing structure you already have:*

| Plan | Price |
|---|---|
| Client | Free + 10% per milestone |
| Developer Free | Free + 10% per milestone, 3 bids/month |
| Developer Pro | KES 999/month + 10% per milestone |

---

*Proposed AI-powered tier:*

Add an *AI tier* on top of existing plans:

| Plan | Price | Who |
|---|---|---|
| Client Free | Free + 10% | Clients, no AI |
| Client Pro | KES 499/month + 8% | Clients, full AI suite |
| Developer Free | Free + 10%, 3 bids | Developers, no AI |
| Developer Pro | KES 999/month + 8% | Developers, AI profile optimizer, bid scorer |
| Developer Elite | KES 1,999/month + 6% | Developers, full AI suite, featured listing, unlimited bids |

---

*Revenue streams:*

*Stream 1 — Subscriptions*

| Users | Plan | Monthly Revenue |
|---|---|---|
| 20 Client Pro | KES 499 | KES 9,980 |
| 30 Dev Pro | KES 999 | KES 29,970 |
| 10 Dev Elite | KES 1,999 | KES 19,990 |
| *Total* | | *KES 59,940/month* |

---

*Stream 2 — Platform fee on milestones*

Assume:
- 50 active contracts per month
- Average milestone value KES 15,000
- Average 3 milestones per contract
- Total milestone volume = 50 × 3 × KES 15,000 = *KES 2,250,000/month*
- Platform takes 10% = *KES 225,000/month*

---

*Stream 3 — Software store (Merchant)*

Assume:
- 20 products selling per month
- Average price KES 2,000
- 10 sales per product = KES 400,000 gross
- Platform takes 15% = *KES 60,000/month*

---

*Stream 4 — AI credits (pay per use)*

For users who don't subscribe but want occasional AI:
- KES 50 per AI brief generation
- KES 30 per bid score
- KES 100 per contract generation
- Assume 200 one-off purchases/month = *KES 8,000/month*

---

*Stream 5 — Hackathon sponsorships*

- Charge companies to sponsor hackathons
- KES 50,000 — 200,000 per hackathon
- 1 hackathon per month = *KES 50,000 — 200,000/month*

---

*Total monthly revenue projection:*

| Stream | Conservative | Optimistic |
|---|---|---|
| Subscriptions | KES 30,000 | KES 120,000 |
| Platform fees (milestones) | KES 50,000 | KES 225,000 |
| Store commissions | KES 15,000 | KES 60,000 |
| AI credits | KES 3,000 | KES 20,000 |
| Hackathon sponsorships | KES 50,000 | KES 200,000 |
| *Total* | *KES 148,000* | *KES 625,000* |

---

*Monthly costs:*

| Cost | Amount |
|---|---|
| Render hosting (pro) | KES 3,000 |
| Cloudinary (media) | KES 2,000 |
| Claude API (AI calls) | KES 10,000 |
| M-Pesa Daraja (per transaction fees) | KES 5,000 |
| Domain + misc | KES 1,000 |
| *Total costs* | *KES 21,000/month* |

---

*Net profit:*

| Scenario | Revenue | Costs | Profit |
|---|---|---|---|
| Conservative (50 users) | KES 148,000 | KES 21,000 | *KES 127,000/month* |
| Optimistic (500 users) | KES 625,000 | KES 21,000 | *KES 604,000/month* |

---

*Break-even point:*

You need just *KES 21,000/month* to cover costs.

That's:
- 3 Developer Pro subscribers, OR
- KES 210,000 in milestone volume (about 15 small contracts), OR
- 1 hackathon sponsor

*You break even with almost no users.*

---

*12 month projection (gradual growth):*

| Month | Users | Revenue | Profit |
|---|---|---|---|
| 1-2 | 10 | KES 20,000 | -KES 1,000 |
| 3-4 | 30 | KES 60,000 | KES 39,000 |
| 5-6 | 80 | KES 150,000 | KES 129,000 |
| 7-9 | 200 | KES 300,000 | KES 279,000 |
| 10-12 | 500 | KES 625,000 | KES 604,000 |

*Year 1 total profit estimate: KES 1.5M — 3M*

---

*Bottom line:*

The platform pays for itself almost immediately. The AI features justify the Pro tiers. The milestone commission is your biggest earner long term — every KES 100,000 in contracts processed puts KES 10,000 in your pocket automatically.

Want to start wiring up the subscription enforcement and AI credit system in code?

[2:19 PM] **June Devis:** I told you there is money in this project if executed properly

[2:20 PM] **June Devis:** Ads are also very profitable

[2:20 PM] **June Devis:** Nenogram is literally a dollar printer

[2:26 PM] **June Devis:** Hapa hata watu wa forex hawatuwezi😂😂

[10:28 PM] **June Devis:** Neno Sphere → people connect
Neno Store → people buy and sell
Neno Hire → people work and hire
Neno Stream → people consume and create content
Neno Play → people compete and innovate
Neno Fund → people finance ideas and businesses
Nenogram Today → people stay informed

[10:28 PM] **June Devis:** More clear vision to work with

[10:29 PM] **June Devis:** Ukimaliza designing the structure unishow

[10:30 PM] **June Devis:** But don't dwell too much on the structure

---

## July 22, 2026

[11:24 PM] **You:** nisha pata the perfect design bro

---

## July 23, 2026

[12:32 AM] **June Devis:** Wagwan kesho nakam unishow

[11:24 PM] **June Devis:** Boyz I picked up my book kwa nyumba yako time ulikua umetoka

---

## July 27, 2026

[1:24 PM] **June Devis:** Yooh

[1:25 PM] **June Devis:** I only managed to raise 500

[1:25 PM] **June Devis:** Weka number ya Mpesa

[1:31 PM] **You:** 0797815942

[1:32 PM] **You:**
> _June Devis: I only managed to raise 500_
pia hiyo  ikosawa

[1:35 PM] **June Devis:** Alafu ile previous logo ya Einstein usiitumie nitaiweka kwa  app ngine

[1:46 PM] **You:**
> _June Devis: Alafu ile previous logo ya Einstein usiitumie nitaiweka kwa  app ngine_
sawa

[1:46 PM] **You:** and thanks man

[1:56 PM] **June Devis:**
> _You: and thanks man_
Cool

---

## July 28, 2026

[8:49 AM] **You:** [Image] these is our exsting data structure

[9:10 AM] **You:** iko clear

[9:10 AM] **June Devis:** Bado najaribu kuielewa

[9:11 AM] **June Devis:** Wacha ntapitia kwa cave unichoreshe

---

## July 30, 2026

[9:40 PM] **You:** stima joo

[9:40 PM] **You:** now back to work

[10:03 PM] **June Devis:**
> _You: stima joo_
Disappointing sana

[10:04 PM] **June Devis:** Have you figured out how to design escrows and wallets?

[10:44 PM] **You:** not yet bado na deal na enviroments for coding

---

## August 1, 2026

[4:06 PM] **June Devis:** Buy NenoCoins
        ↓
Wallet receives coins
        ↓
Join live stream
        ↓
Click Gift
        ↓
Choose amount
        ↓
Coins transferred
        ↓
Creator balance increases
        ↓
Creator withdraws earnings

[4:07 PM] **June Devis:** Above is just a basic gifting system for nenogram

[4:08 PM] **June Devis:** We will design coins that would be reffered to as " Neno coins "

[4:19 PM] **June Devis:** We could also use this system to allow people to tip bloggers among other areas of nenogram

[4:20 PM] **June Devis:** Don't mind the design it's just a sketch it still needs research and refinement

[5:15 PM] **June Devis:** We should also focus on various areas within the nenogram where  the nenocoins could be used

[5:16 PM] **June Devis:** _This message was deleted_

---

## August 2, 2026

[7:53 PM] **June Devis:** [Image]

[7:53 PM] **June Devis:** Color preference

[7:53 PM] **June Devis:** Midnight Blue + Electric Cyan ⭐ (my top recommendation)
Primary: #0B1020
Accent: #00D4FF
Secondary: White: create a visual

---

## August 3, 2026

[12:10 AM] **You:**
> _June Devis: Image_
These is cool bro

[3:31 PM] **You:** https://youtu.be/2LQXrGKq3t0?si=12ApSQPZVcUcLllo

---

## August 4, 2026

[8:48 AM] **June Devis:** Yooh

[8:48 AM] **June Devis:** Fundi anakam  leo

[9:36 AM] **You:** Fiti man

[4:34 PM] **June Devis:** Niletee cable ya charger yako

[11:03 PM] **You:** yo ushalala

[11:04 PM] **June Devis:** Bado ndio nadai

[11:06 PM] **You:** nikamie charger ama kesho

[11:06 PM] **June Devis:** Kesho morning

[11:07 PM] **You:** fiti

[11:07 PM] **You:** lala msee nauote ile vids ya ule msee akiwa slaughtered

[11:08 PM] **June Devis:** Fucking lol

[11:08 PM] **You:** 😂

[11:08 PM] **You:** maskio bro

[11:08 PM] **June Devis:** Fala doz

[11:09 PM] **You:** bado hiyo staff ina ni haunt to kwa kichwa

[11:09 PM] **June Devis:** Nilikuwarn

[11:10 PM] **You:** imagine ugenunua ile panga alafu hiyo ndio ana tumia

[11:11 PM] **June Devis:**
> _You: imagine ugenunua ile panga alafu hiyo ndio ana tumia_
Itabidi ninunue alafu ikue security

[11:11 PM] **You:** bana

[11:11 PM] **June Devis:** Huku nje wasee n wanyama

[11:11 PM] **June Devis:** Nikiweza nashika gun

[11:12 PM] **You:** kama nikutoana maskio ni kutoana maskio

[11:12 PM] **June Devis:** Manze lakini human being pretend to be civilized but they are not

[11:15 PM] **You:** their animalistic nature

---

## August 5, 2026

[1:44 AM] **You:** https://youtu.be/ibrjXMXMNP8?si=Os7XEDGBkiOM7dxZ

[10:08 AM] **June Devis:** Yooh

[10:08 AM] **June Devis:** Kujia charger

---

## August 6, 2026

[9:40 AM] **June Devis:** [Video]

[9:40 AM] **June Devis:** N mbaya😂😂

[9:42 AM] **You:** no underwear bro😂

[9:43 AM] **June Devis:** Crazy

[12:59 PM] **June Devis:** Charger ya lapii imefika

[1:01 PM] **You:** bado

[1:02 PM] **You:** [Image]

[1:02 PM] **June Devis:** Wagwan

[1:21 PM] **You:** [Document] streaming program

[1:24 PM] **You:** and these is just the first step

[1:24 PM] **You:** [Image] here is the full map

[1:25 PM] **June Devis:** Complex

[1:26 PM] **You:**
> _June Devis: Complex_
i never thought to be that complex

[1:26 PM] **June Devis:** Na bado

[3:21 PM] **June Devis:** Yooh niuzie hiyo unga yako

[3:21 PM] **You:** leta mia bro

[3:21 PM] **June Devis:** Tuma picha inatosha aje

[3:22 PM] **You:** niko busy saa hii bro ngoja kwanza nitatuma

[3:31 PM] **You:** ama come ucheki kwanza

[10:25 PM] **June Devis:** Kesho ukujie charger mapema

---

## August 9, 2026

[11:01 AM] **You:** bro anza kutegeneza community in social media platform

[11:03 AM] **You:** https://youtu.be/XXXu6kwdTuc?si=IcSgTYj0PpO8tWpt

[11:20 AM] **June Devis:**
> _You: bro anza kutegeneza community in social media platform_
Wazi

[11:26 AM] **You:** [Image]

[1:18 PM] **You:** [Image] white mode

[1:20 PM] **June Devis:**
> _You: Image: white mode_
Bro I'm out of words

[1:29 PM] **You:** na bado msee

[7:33 PM] **June Devis:** Yooh msee

[7:34 PM] **June Devis:** Kam na charger simu yangu inadedi

[7:50 PM] __[Call]__

---

## August 10, 2026

[8:27 PM] **June Devis:** Nenogram's social media presence is almost through in all important platforms

---

## August 15, 2026

[7:38 PM] **You:** yo wifi yako ya twenty four hour ina fanya

[7:41 PM] **June Devis:** Iko fity

[9:07 PM] **You:** Can you please share all the conversations you were having with ChatGPT? I am looking for something.

[9:09 PM] **June Devis:** I've had many conversation with chat gpt, be specific about the topic

[9:09 PM] **You:** about nenogram

[9:09 PM] **June Devis:** Wueh they are kinda mixed up

[9:09 PM] **You:** just find the share   button

[9:23 PM] **You:** yo

[9:35 PM] **June Devis:** Wueh bulanda

[10:01 PM] **You:** [Image] sorry bro nisha access account 🤣

[10:03 PM] **You:** but i will  be looking for the most important details nothing more

[10:06 PM] **You:** Now I can even see what you’re referring to as matchmaking.

[10:21 PM] **June Devis:**
> _You: Image: sorry bro nisha access account 🤣_
Sipendi upizi!!!!

[10:22 PM] **You:** what bro

[10:22 PM] **You:** i just needed  a quick reference , na account yako iko tu hapa

[10:37 PM] **You:** beg for forgiveness if i did wrong bro , i should have asked first

---

## August 16, 2026

[3:08 AM] **June Devis:**
> _You: beg for forgiveness if i did wrong bro , i should have asked first_
Wazi haina mambo

[1:49 PM] **You:** What is the NenoCoin exchange rate?

Fixed? (1 NenoCoin = 10 KES always)
Dynamic? (market-driven like crypto)
If dynamic — who sets the price? You? Supply/demand?

[2:13 PM] **June Devis:** The market should determine its price

[2:14 PM] **June Devis:** We first establish an initial reference rate then the market will take it from there

[2:14 PM] **You:** If NenoCoin is market-driven like crypto, you need:

A price discovery mechanism — what sets the price? Trading volume? Platform algorithm? Oracle?
A liquidity pool — someone has to be on the other side of every buy/sell
Real-time price feeds — every transaction needs the current rate
Price manipulation protection — what stops someone from gaming the rate?

[2:17 PM] **June Devis:**
> _You: If NenoCoin is market-driven like crypto, you need:

A price discovery mechanism — what sets the price? Trading volume? Platform algorithm? Oracle?
A liquidity pool — someone has to be on the other side of every buy/sell
Real-time price feeds — every transaction needs the current rate
Price manipulation protection — what stops someone from gaming the rate?_
I agree

[2:18 PM] **June Devis:** Let me research

[2:20 PM] **June Devis:** Keep in mind nenocoins work within nenogram ecosystem

[2:21 PM] **June Devis:** The coin itself is not crypto

[2:24 PM] **June Devis:** I think making the coin to be market driven will not be a good idea

[2:24 PM] **June Devis:** It will make gifting making purchases very difficult

[2:26 PM] **June Devis:** Imagine you want to gift a content creator ksh 100 in nenocoins then you find out that one nenocoin is ksh1000

[2:28 PM] **June Devis:** The best option is for nenogram to set and maintain the value

[2:29 PM] **June Devis:** 1 NNC = 10 KES
10 NNC = 100 KES
100 NNC = 1,000 KES
1,000 NNC = 10,000 KES

[2:30 PM] **June Devis:** This is just for kenya

[2:31 PM] **You:** so ikuwee to fix  alafu hi ya crytpo ni later

[2:32 PM] **June Devis:**
> _You: so ikuwee to fix  alafu hi ya crytpo ni later_
Kabisaa

[2:34 PM] **June Devis:** Since nenogram is going international the value of the coin should be constant accross all currencies

[2:34 PM] **June Devis:** Si unajua kuna currencies zingine powerful kushinda zingine

[2:35 PM] **June Devis:** For example Kenyan shilling is more powerful than Tanzanian shilling

[2:38 PM] **June Devis:** The value of the coin should change as per the value of the different types of currencies

[2:42 PM] **June Devis:** User location
Local currency
1 NNC
🇰🇪 Kenya
KES
10 KES
🇺🇸 USA
USD
~$0.07
🇬🇧 UK
GBP
~£0.05
🇪🇺 Eurozone
EUR
~€0.06
🇳🇬 Nigeria
NGN
~₦100
🇿🇦 South Africa
ZAR
~R1.25

[2:44 PM] **June Devis:** someone in Kenya and someone in the US both see:
100 NNC
But the amount they pay to acquire those 100 NNC is displayed in their own currency.

[3:41 PM] **You:** noted📝

---

## August 17, 2026

[10:11 AM] **You:** [Document] a more cleaner,compresed and smater version of the project

[12:44 PM] **You:** who will be creating the hackathongs

[12:46 PM] **June Devis:**
> _You: who will be creating the hackathongs_
Sponsors will be given opportunity to create/ design or suggest hackathons

[12:47 PM] **June Devis:** Other hackathons will be based. On current problems/ challenges in tech

[12:49 PM] **June Devis:** Other hackathons will be designed to source talent or employees for organizations or companies  for example  if cyber security experts are needed or Game desighners

[12:50 PM] **June Devis:** Suggestions from the nenogram community/users can be used to design hackathons

[12:51 PM] **June Devis:** In general Nenogram, Nenogram community, Organizations, prevailing tech problems etc

[12:52 PM] **June Devis:** Ai could also be used  to create hackathons on behalf of Nenogram

[12:52 PM] **June Devis:** There are many ways

[12:57 PM] **June Devis:** As a matter of fact we could create specific conditions to allow anyone to create hackathons

[12:57 PM] **June Devis:** Like rules and guidelines

[12:58 PM] **June Devis:** Challenge/problem
Rules
Duration
Eligibility
Prize/NenoCoin rewards
Submission requirements
Judging criteria
Sponsors
Number of winners

[12:58 PM] **You:** 📝

[1:01 PM] **June Devis:** So Nenogram doesn't have to create every hackathon itself—it can become a global platform where anyone authorized can create and run hackathons.

---

## August 18, 2026

[2:16 PM] **You:** yo stima ime come

[6:36 PM] **June Devis:** Imekam

---

## August 19, 2026

[9:17 AM] **June Devis:** I was just researching on Afriglove and found out that in as much as competition in this field is stif we have a pretty good chance to make huge sums of money in a very short period if we register higher returns minimal  losses  quick recovery after losses and transparency to some level

[9:18 AM] **June Devis:** Competition is not our main problem results are

[9:19 AM] **June Devis:** I'm working on developing a master strategy that will work for us

---

## August 21, 2026

[3:42 PM] **You:** Alright, here’s the master plan: I’ll whip up a fancy landing page that dazzles like a disco ball. Since I’m a social media newbie, we’ll recruit a celebrity who knows their hashtags from their hash browns, hand them the link, and let them sprinkle it across the internet. That way, when folks click, they’ll land right in our product wonderland and see everything we’re selling. Then, at launch, we send them the link again so they can marvel at how we actually delivered on our grand promises.

[4:11 PM] **You:** https://www.inoreader.com/search/feeds/category/tech-news-trends

---

## August 22, 2026

[5:25 PM] **You:** Yoo ishafika

---

## August 24, 2026

[3:22 PM] **You:** but if I get some money i will buy some share on your cookies company

[6:23 PM] **June Devis:**
> _You: but if I get some money i will buy some share on your cookies company_
Ok

[6:56 PM] **You:** https://www.jumia.co.ke/generic-car-refrigerator-12v-7.5l-mini-home-camping-fridge-electric-cool-box-cooler-warmer-travel-portable-box-freezer-328579862.html

[7:08 PM] **You:** yo i want you to do research on the inventory management system

[7:09 PM] **You:** then send for what you have found

[7:09 PM] **June Devis:** Do it and let me know

[7:26 PM] **You:** yo nisha pata some developers firms in kenya whome we can approach themhttps://share.google/wdbXmkliTLTnBPaeo

[7:36 PM] **You:** another firm  https://www.questdesigners.com/contact-us

[7:40 PM] **You:** potential guy +254 722 476434

---

## August 27, 2026

[2:49 PM] **You:** yo

[7:23 PM] **June Devis:** Yo

[10:14 PM] **June Devis:** [Image]

[10:15 PM] **June Devis:** Use it to create the final logo

---

## August 28, 2026

[9:07 PM] **You:** yo what a long day

---

## August 29, 2026

[1:01 PM] **You:** https://www.jumia.co.ke/generic-l-mini-fridge-beverage-refrigerator-makeup-fridge-white-309716999.html

[5:24 PM] **June Devis:**
> _You: https://www.jumia.co.ke/generic-l-mini-fridge-beverage-refrigerator-makeup-fridge-white-309716999.html_
😂😂

[5:24 PM] **June Devis:** Kwani ni toy

[5:24 PM] **You:** 😂

---

## August 31, 2026

[1:17 PM] **You:** fuck mzsee i thought ita take long but kukmbe in faster to

[1:17 PM] **June Devis:**
> _You: fuck mzsee i thought ita take long but kukmbe in faster to_
Imekua app

[1:17 PM] **June Devis:** Ama?

[1:19 PM] **You:** nipee ten min then nikutumie link

[1:19 PM] **June Devis:** Wazi

[2:40 PM] **You:** fuck mzee

[2:40 PM] **You:** [Document] app-debug.apk

[2:45 PM] **You:** [Image] Kwa tablet

[2:49 PM] **You:** let me now cook these ledger

[3:27 PM] **June Devis:** Bro that looks really good

[3:36 PM] **You:** screenshot bro

[3:39 PM] **You:** Ok, from there just describe everything you wanted.

[3:41 PM] **June Devis:** I'd number entry

[3:42 PM] **June Devis:** And the system should support client's photo

[3:43 PM] **You:** ebu screennshot i see how it look  kwa phone

[3:43 PM] **You:** for both dark mode and light mode

[3:44 PM] **June Devis:** It is still installing just a moment

[3:45 PM] **June Devis:** [Image]

[3:46 PM] **You:** light mode

[3:46 PM] **June Devis:** [Image]

[3:46 PM] **June Devis:** Bro it looks fantastic , mind you this is just version 1

[3:47 PM] **You:** fuck  msee , i realy thought ita take time but kumbe just few click ,

[3:48 PM] **June Devis:** Crazy

[3:48 PM] **You:** bro ama tuanze ku scam fresha

[3:48 PM] **You:** 😂

[3:48 PM] **June Devis:** Scum ni tamu

[3:49 PM] **June Devis:** Sasa weka logo ya cyberlend kwa app

[3:49 PM] **You:** ok click hiyo logo ina kaa kama chart

[3:50 PM] **You:** then screenshot

[3:50 PM] **You:** analytics

[3:51 PM] **June Devis:** [Image]

[3:51 PM] **June Devis:** [Image]

[3:52 PM] **You:**
> _June Devis: Sasa weka logo ya cyberlend kwa app_
i think zita kuwa perfetc kwa big screen

[3:52 PM] **June Devis:** Probably

[3:52 PM] **June Devis:** Sasa wacha tufanye final touches na perfection

[3:57 PM] **You:** ok unstall hiyo then install the new one and check th luancher icone in the homepage

[3:58 PM] **You:** [Document] app-debug.apk

[4:02 PM] **June Devis:** Bado logo inakaa runny it needs refining

[4:02 PM] **You:** workingon that

[4:04 PM] **You:** [Document] i will be using these for now

[4:05 PM] **June Devis:** First check if it's being used elsewhere

[4:09 PM] **You:** sioni msee aki tumia , no officail site the same logo , it brand new generated logo with gemiini , though i will tweak some color in it

[4:09 PM] **June Devis:** I think it's cool

[4:10 PM] **June Devis:** Just a little adjustments

[4:11 PM] **June Devis:** Add meighby the name cyberlend

[4:12 PM] **You:** one thing to note that logo is know as the launcher logo

[4:13 PM] **You:** itakuwa tu hapo kwa main home page, but the main logo itakuwa tuu the man logo

[4:14 PM] **June Devis:** I agree  but add cyberlend for uniqueness just like Lamborghini

[4:14 PM] **June Devis:** Many entities use variants of the raging bull

[4:15 PM] **June Devis:** The name cyberlend will make the logo very unique

[4:15 PM] **June Devis:** But generally the logo looks ok to me

[4:22 PM] **You:** ok now unstall the existing one then install these one

[4:22 PM] **You:** [Document] app-debug.apk

[4:23 PM] **You:** then tell how it look , or screen shot i see

[4:25 PM] **June Devis:** Logo bado

[4:25 PM] **You:** screeen shot

[4:26 PM] **June Devis:** [Image]

[4:26 PM] **June Devis:** Nothing changed

[4:27 PM] **You:** nono , achana hiyo kwanza i mean this

[4:27 PM] **You:** [Image]

[4:27 PM] **June Devis:**
> _You: nono , achana hiyo kwanza i mean this_
What?

[4:28 PM] **June Devis:** [Image]

[4:28 PM] **You:** [Image]

[4:29 PM] **You:** ok what about hii part

[4:29 PM] **June Devis:** [Image]

[4:29 PM] **You:** how does it look

[4:29 PM] **June Devis:** Nothing changed

[4:30 PM] **June Devis:** Ya nje looks alright

[4:30 PM] **You:** [Image] ok now at first ilikuwa hivi

[4:30 PM] **June Devis:** But ndani ya app it's very runny

[4:31 PM] **June Devis:** Exterior logo looks perfect but interior logo is still idk runniny

[4:31 PM] **You:** [Image] then ikuwa then ikakuwa hivi

[4:32 PM] **June Devis:** Hiyo icon y cyberlend ya app ndani sio clear

[4:32 PM] **June Devis:** Nje iko sawa

[4:33 PM] **June Devis:** [Image]

[4:33 PM] **June Devis:** Very runny

[4:33 PM] **You:** ok now will dealling with the background image  just just to make sure imefit  kwa frame

[4:33 PM] **June Devis:** Ok

[5:42 PM] **June Devis:** Add entry for Available loan funds/loanable funds

[5:43 PM] **You:**
> _June Devis: Add entry for Available loan funds/loanable funds_
noted

[9:38 PM] **June Devis:** [Document] Scanned_20260831_194340.pdf

---

## September 1, 2026

[7:48 PM] **June Devis:** "Fast Honest Reliable

---

## September 2, 2026

[7:21 PM] **June Devis:** Yooh

---

## September 4, 2026

[8:31 PM] **June Devis:** Yooh

[10:10 PM] **You:** [Document] app-debug.apk

[10:33 PM] **You:** [Document] app-debug.apk

[10:46 PM] **You:** [Document] app-debug.apk

[11:22 PM] **You:** [Document] app-debug.apk

---

## September 5, 2026

[12:16 AM] **You:** [Document] app-debug.apk

[1:04 AM] **You:** [Document] app-debug.apk

[1:12 AM] **June Devis:** _This message was deleted_

[1:16 AM] **June Devis:** [Image]

---

## September 7, 2026

[9:01 PM] **You:** [Document] app-debug.apk

[9:02 PM] **June Devis:** 0707997092

[9:47 PM] **You:** [Document] app-debug.apk

---

## September 10, 2026

[7:50 PM] **June Devis:** [Image]

---

## September 11, 2026

[8:02 PM] **June Devis:** Bro umecode leo

[8:34 PM] **You:** Busy bro

---

## September 16, 2026

[10:27 AM] **You:** [Document]

[10:47 AM] **You:** [Document]

[8:16 PM] **June Devis:** [Image]

---

## September 24, 2026

[7:27 PM] **You:** yo kesho bro sijui umejipanga aje

[7:41 PM] **June Devis:** Nko on

[7:46 PM] **You:** saa ngapi

[7:47 PM] **June Devis:** By saa nne

[7:47 PM] **June Devis:** Ndio watu wakue wametokea

---

## September 27, 2026

[9:12 AM] **June Devis:** LOAN AGREEMENT FORM

Agreement No.: __________
Application ID: __________
Agreement Version: ____
Date: __ / __ / ____

---

1. PARTIES

1.1 LENDER

Full Name / Legal Name: ________________

ID/Registration No.: _________________

Postal/Physical Address: _______________

Telephone: __________

Email: __________

Hereinafter referred to as the “Lender.”

1.2 BORROWER

Full Name: ____________________

National ID/Passport No.: ________________

Date of Birth: __ / __ / ____

Postal/Physical Address: _______________

Telephone: __________

Email: __________

Occupation/Business: _________________

Employer/Business Name: _______________

Hereinafter referred to as the “Borrower.”

1.3 GUARANTOR — IF APPLICABLE

Full Name: ____________________

National ID/Passport No.: ________________

Physical Address: __________________

Telephone: __________

Email: __________

Occupation/Business: _________________

---

2. LOAN FACILITY

The Lender agrees to provide the Borrower with a loan subject to the terms and conditions contained in this Agreement.

Requested Loan Amount: KES __________

Approved Loan Amount: KES __________

Amount in Words:

---

Loan Purpose:

---

---

Date of Disbursement: __ / __ / ____

Expected Final Repayment Date: __ / __ / ____

Loan Term: __________ months.

---

3. INTEREST

Interest Rate: ____ %

Interest Basis:

☐ Flat Rate

☐ Reducing Balance

☐ Other: ________________

Interest Calculation Method:

---

---

Total Interest Payable, if predetermined: KES ________

---

4. FEES AND CHARGES

Processing/Application Fee:

☐ None

☐ ____ %

☐ KES ______

Other Applicable Fee(s):

---

---

Total Fees: KES __________

---

5. NET AMOUNT DISBURSED

Approved Loan Amount: KES ______

Less Applicable Fees/Deductions: KES ______

Net Amount to be Disbursed: KES ______

The Borrower acknowledges that the amount actually received may differ from the approved loan amount where lawful and agreed fees or deductions apply.

---

6. DISBURSEMENT

The loan shall be disbursed through:

☐ Mobile Money

☐ Bank Transfer

☐ Cheque

☐ Cash

☐ Other: ____________

Account/Phone Number: ________________

Disbursement Reference: _______________

The Borrower confirms that the details provided for disbursement are correct.

---

7. REPAYMENT

The Borrower shall repay the loan according to the repayment schedule attached to this Agreement.

Repayment Frequency:

☐ Daily

☐ Weekly

☐ Bi-weekly

☐ Monthly

☐ Other: __________

Number of Instalments: ______

Amount per Instalment: KES ______

First Payment Date: __ / __ / ____

Final Payment Date: __ / __ / ____

Payment Method:

☐ Mobile Money

☐ Bank Transfer

☐ Other: ____________

Payment Account/Number: _______________

A payment shall be considered received when successfully credited to the designated payment account or otherwise acknowledged by the Lender.

---

8. REPAYMENT SCHEDULE

Instalment| Due Date| Principal| Interest| Fees/Charges| Total Due| Balance
1| ___| KES __| KES __| KES __| KES __| KES ___
2| ___| KES __| KES __

[9:13 AM] **June Devis:** Add to loan management system then send apk

---

## September 30, 2026

[8:41 PM] **You:** yo friday plans

---

## October 1, 2026

[5:55 AM] **June Devis:**
> _You: yo friday plans_
Networking

[10:34 AM] **June Devis:** Adi jana nilinetwork side ya masoldier

[10:34 AM] **June Devis:** So tunaenda department ngine

[11:25 AM] **You:** [Document]

[11:29 AM] **June Devis:** Yooh

[11:29 AM] **You:** uko wapi

[11:50 AM] **June Devis:** [Image]

---

## October 10, 2026

[11:53 AM] **You:** [Document] phew finally after a long trial the apk now works ,

[11:54 AM] **You:** so what to do check it out write down all possible changes then send me a list

[11:54 AM] **You:** click that agree button.

[11:56 AM] **June Devis:** Tuma ngine haiload

[11:56 AM] **You:** [Document]

[11:59 AM] **You:** imefunguka

[11:59 AM] **June Devis:** Yeeah

[12:00 PM] **You:** okay write a check list of all possible changes

[12:00 PM] **June Devis:** Hapo kwa period make it in such a way I can type  in any period of my choice

[12:00 PM] **June Devis:** Loanable asset entry

[12:01 PM] **June Devis:** Client search

[12:01 PM] **June Devis:** Risk entry for high risk client

[12:03 PM] **June Devis:** How does the agreement part work?

[12:05 PM] **June Devis:** It is supposed to be at the entry for new loans per client

[12:07 PM] **You:** all noted

[12:08 PM] **June Devis:** The notes part is the agreement

[12:08 PM] **June Devis:** ?

[12:09 PM] **You:**
> _June Devis: The notes part is the agreement_
i meant all proposed changes are noted

[12:09 PM] **June Devis:** Cool

[12:10 PM] **You:** keep scaning and searching

[12:11 PM] **You:**
> _June Devis: Risk entry for high risk client_
but kwa hii we need a systematic way of identifying risk client

[12:11 PM] **June Devis:**
> _You: but kwa hii we need a systematic way of identifying risk client_
I have a few

[12:11 PM] **June Devis:** Enter will be manual

[12:11 PM] **June Devis:** I will enter

[12:12 PM] **You:** but also risk client are the same as the defaulters
?

[12:12 PM] **June Devis:** No

[12:13 PM] **June Devis:** They might not be defaulters but  still risky

[12:15 PM] **You:** [Image] So Nita add one categorizer ya risky borrowers hapo  hizo categorizer

[12:16 PM] **You:** so itakuwa kama budge

[12:16 PM] **June Devis:** Sawa

[12:27 PM] **June Devis:** Also do something on the client profile part

[12:28 PM] **June Devis:** It should be able to upload a client photo for easy and precise identification

[12:29 PM] **June Devis:** Also Id number to avoid kurukwa

[12:30 PM] **June Devis:** That's all for now

[12:32 PM] **You:** 📝📝  NOTED mkuu

[6:54 PM] **You:** [Document] now check out these

[7:00 PM] **You:** check list searching feature,risk flaging when  adding new client , aslo while adding a new loan we have the button that will redirect you to filling agreement modal.

[7:01 PM] **You:** so pia laonable asset , it kuwa hapo card ya available

[7:06 PM] **June Devis:** Bro good job

[7:06 PM] **June Devis:** Let's see how it works

[7:07 PM] **June Devis:** I'll notify you of any flaws

[7:10 PM] **June Devis:** I'd entry

[7:11 PM] **June Devis:** Also adjust the loan period some people might need loans for a week

[7:12 PM] **June Devis:** Meighby 26 days etc

[7:12 PM] **You:**
> _June Devis: I'd entry_
check hiyo while adding a new client

[7:14 PM] **June Devis:**
> _You: check hiyo while adding a new client_
Haiko

[7:17 PM] **You:** [Image]

[7:17 PM] **You:**
> _June Devis: Meighby 26 days etc_
wacha deal na hii

[7:17 PM] **June Devis:** [Image]

[7:17 PM] **June Devis:** Wapi?

[7:17 PM] **You:**
> _June Devis: Image_
kwa new client

[7:18 PM] **You:** not new loan

[7:18 PM] **June Devis:** Haiko inafaa ikue kwa new loan

[7:19 PM] **You:** sijui kama unakumbuka logic , new client , then waiting list , after approval new loan

[7:20 PM] **June Devis:** Bro haiko

[7:20 PM] **You:** screenshot

[7:20 PM] **June Devis:** Weka kwa new loan

[7:20 PM] **You:** wacha ni come hapo

---

## October 13, 2026

[10:11 PM] **June Devis:** Yooh umemaliza?

---

## October 14, 2026

[7:28 AM] **You:** Bado mzee

[7:29 AM] **You:** These week everything will be done

---

## October 15, 2026

[12:24 PM] **June Devis:**
> _You: Image: Mark 10:27 “Jesus looked at them and said ‘With man this is impossible, but not with God; all things are possible with God’ ”_
Son you deep in religion

[12:24 PM] **June Devis:**
> _You: Image: Mark 10:27 “Jesus looked at them and said ‘With man this is impossible, but not with God; all things are possible with God’ ”_
😂

[12:26 PM] **You:**
> _June Devis: Son you deep in religion_
am always deep in it

---

## October 16, 2026

[4:23 PM] **You:** yo stima imerudi

[5:01 PM] **June Devis:** Iko

[5:25 PM] **June Devis:** Nishaa chapa ile teo

[5:26 PM] **June Devis:** Sahii login imekua rahisi kwa e learning

---

## October 17, 2026

[10:08 PM] **You:** Yo 🤘

[10:08 PM] **You:** Am getting bugs but still working on it

[11:04 PM] **June Devis:** Cool make it a masterpiece

---

## October 18, 2026

[1:35 PM] **You:** [Document] app-debug.apk

[4:43 PM] **June Devis:** Bro concept ya hizi analytics haieleweki

[4:55 PM] **June Devis:** Ama implement search bar kwa analytics

[5:00 PM] **June Devis:** Sasa clients wakiwa  in hundreds fikiria tu kama analytics itaoperate aje

[5:00 PM] **June Devis:** Hii bado

[5:03 PM] **June Devis:** Issue iko kwa hiyo part ya ku analyse clients

[5:03 PM] **June Devis:** Mwingine iko pos

[5:03 PM] **June Devis:** Client part

---

## October 20, 2026

[7:57 PM] **June Devis:** Bro

[8:10 PM] **You:** Yo

[8:10 PM] **You:** Net iko

---

## October 21, 2026

[6:41 AM] **June Devis:** Check for all the hardware gadgets needed to run cyberlend efficiently and give me the budget

[2:07 PM] **June Devis:** Iko, washaa repair

[2:07 PM] **You:** nice then i will on my  way back

[10:51 PM] **June Devis:** Yooh wifi iko?

[10:57 PM] **You:** yap

[10:58 PM] **June Devis:** Mafala walikua wanataka kuchukua wifi

[10:59 PM] **June Devis:** Nimetoa panga bana

[10:59 PM] **June Devis:** Ilibidi

[11:01 PM] **You:**
> _June Devis: Mafala walikua wanataka kuchukua wifi_
😅

[11:01 PM] **You:** akina mulunda

[11:02 PM] **June Devis:** Karibu kijana aitane

[11:02 PM] **June Devis:** Wameiwacha kwa mlango😂😂

[11:02 PM] **June Devis:** Ukiwa weak utabebwa ufala

[11:02 PM] **You:** huyo jama anakuanga na kihere

[11:02 PM] **You:** here

[11:03 PM] **June Devis:** Bana we endelea kuchonga system

[11:03 PM] **June Devis:** Umefikia wapi

[11:03 PM] **You:** flexing

[11:03 PM] **You:** techincal part of it

[11:04 PM] **June Devis:**
> _You: techincal part of it_
What have you dealt with specifically

[11:05 PM] **You:** getiing new knowledge about flexing

[11:06 PM] **You:** they are some series of things i need to know before moving forward.

---

## October 25, 2026

[4:21 PM] **You:** Have been having aa mental breakdown  recently and i believe i have recovered , so soon thing wiill ok

[4:31 PM] **June Devis:**
> _You: Have been having aa mental breakdown  recently and i believe i have recovered , so soon thing wiill ok_
Cool

[4:31 PM] **June Devis:** There is a lot to be done

---

## October 29, 2026

[4:59 AM] **June Devis:** Buda strike inaisha kesho 30th

[5:00 AM] **June Devis:** Sioni hiyo software ikimake

[5:03 AM] **June Devis:** Na hii story nilikua nishaa kuambia sasa ona mwezi moja free ishaa potea tu ivo

[5:05 AM] **June Devis:** One thing about me it's either you shape in or out

[7:08 AM] **You:** Ok bro give twenty four hours

[7:51 AM] **You:** Yo I need you to create a check list of everything you requested.

[7:53 AM] **You:** All the features

[7:53 AM] **June Devis:** Ok

[7:56 AM] **June Devis:** Investors part
Collection + arrears 
Notifications
Clients ID upload
Scrolling effect where necessary

[7:57 AM] **June Devis:** Animation
Security
Clients fingerprint upload

[7:58 AM] **June Devis:** Removal of all unnecessary buttons or features

[8:03 AM] **You:** Anything more

[8:07 AM] **June Devis:** The loan agreement part we agreed it should be part of the loan creation process

[8:07 AM] **June Devis:** Logo

[8:07 AM] **June Devis:** Any flaws that might be present

[8:10 AM] **You:**
> _June Devis: The loan agreement part we agreed it should be part of the loan creation process_
[Image]

[8:11 AM] **You:** Shall we remove that.

[8:13 AM] **June Devis:** It should be part of creating the loan the final part  but it should be flexible to change or renew etc

[8:13 AM] **June Devis:** It's good though

[8:15 AM] **June Devis:** It should show in the client's data

[8:18 AM] **You:**
> _June Devis: It should show in the client's data_
How ?

[8:19 AM] **June Devis:**
> _You: How ?_
Are you around

[8:20 AM] **You:** Not really Niko shule

[8:22 AM] **You:**
> _June Devis: It should show in the client's data_
Give me reference

[8:24 AM] **June Devis:** For example in a clients data I should be able to see the name photo ID etc + all agreements

[8:25 AM] **You:**
> _June Devis: For example in a clients data I should be able to see the name photo ID etc + all agreements_
Now I see

[8:26 AM] **June Devis:** You've really done a good job so far it's just polishing  and setting up one or two things

[8:27 AM] **June Devis:** If possible the system should have a very unique way to assign clients with identity

[8:28 AM] **June Devis:** Like a code or something
